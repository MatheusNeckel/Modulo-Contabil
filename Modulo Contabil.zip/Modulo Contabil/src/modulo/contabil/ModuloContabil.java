package modulo.contabil;

import java.util.ArrayList;
import java.util.Scanner;

public class ModuloContabil {

    public static void main(String[] args) {
        ArrayList<Imposto> pagamentos = new ArrayList<>();
        Scanner entrada = new Scanner(System.in);
        String descricao = "";
        int count = 0;

        System.out.println("----Cadastro de Impostos----");

        do {
            System.out.print("\nDigite o tipo de imposto: ");
            descricao = entrada.next();

            if (descricao.equalsIgnoreCase("PARE")) {
                break;
            }

            if (descricao.equalsIgnoreCase("PIS")) {
                System.out.print("Digite o valor do débito: ");
                double valorDebito = entrada.nextDouble();
                System.out.print("Digite o valor do crédito: ");
                double valorCredito = entrada.nextDouble();

                PIS p = new PIS(valorDebito, valorCredito, descricao);
                pagamentos.add(p);
            } else if (descricao.equalsIgnoreCase("IPI")) {
                System.out.print("Digite o valor do produto: ");
                double valorProduto = entrada.nextDouble();
                System.out.print("Digite o valor do frete: ");
                double frete = entrada.nextDouble();
                System.out.print("Digite o valor do seguro: ");
                double seguro = entrada.nextDouble();
                System.out.print("Digite o valor das outras despesas: ");
                double outrasDespesas = entrada.nextDouble();
                System.out.print("Digite o valor da alíquota: ");
                double valor = entrada.nextDouble();
                double aliquota = valor * (valor / 100);
                IPI i = new IPI(valorProduto, frete, seguro, outrasDespesas, aliquota, valor, descricao);
                pagamentos.add(i);
            } else {
                System.out.println("Tipo de imposto inválido! Tente novamente.");
            }
        } while (!descricao.equals("PARE"));

        count++;

        for (int i = 0; i < pagamentos.size(); i++) {
            System.out.println("\n");
            System.out.println(pagamentos.get(i).getDescricao());
            System.out.println("Total do imposto: R$ " + pagamentos.get(i).calcularImposto());
        }
    }
}
