package modulo.contabil;

public class PIS implements Imposto {

    private String descricao;
    private double valorDebito, valorCredito;

    public PIS(double valorDebito, double valorCredito, String descricao) {
        this.valorDebito = valorDebito;
        this.valorCredito = valorCredito;
        this.descricao = descricao;
    }

    @Override
    public double calcularImposto() {
        return (valorDebito - valorCredito) * 0.0165;
    }

    @Override
    public String getDescricao() {
        return this.descricao;
    }

    public double getValorDebito() {
        return valorDebito;
    }

    public void setValorDebito(double valorDebito) {
        this.valorDebito = valorDebito;
    }

    public double getValorCredito() {
        return valorCredito;
    }

    public void setValorCredito(double valorCredito) {
        this.valorCredito = valorCredito;
    }
}
