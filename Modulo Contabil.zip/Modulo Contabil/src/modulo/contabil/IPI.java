package modulo.contabil;

public class IPI implements Imposto {

    private String descricao;
    private double valorProduto, frete, seguro, outrasDespesas, aliquota;
    private double valor;

    public IPI(double valorProduto, double frete, double seguro, double outrasDespesas, double aliquota, double valor, String descricao) {
        this.valorProduto = valorProduto;
        this.frete = frete;
        this.seguro = seguro;
        this.outrasDespesas = outrasDespesas;
        this.aliquota = aliquota;
        this.valor = valor;
        this.descricao = descricao;
    }

    @Override
    public double calcularImposto() {
        return calcularBaseDeCalculo() * calcularAliquota();
    }

    @Override
    public String getDescricao() {
        return this.descricao;
    }

    public double calcularBaseDeCalculo() {
        return valorProduto + frete + seguro + outrasDespesas;
    }

    public double calcularAliquota() {
        return aliquota = (valor / 100);
    }

    public double getValorProduto() {
        return valorProduto;
    }

    public void setValorProduto(double valorProduto) {
        this.valorProduto = valorProduto;
    }

    public double getFrete() {
        return frete;
    }

    public void setFrete(double frete) {
        this.frete = frete;
    }

    public double getSeguro() {
        return seguro;
    }

    public void setSeguro(double seguro) {
        this.seguro = seguro;
    }

    public double getOutrasDespesas() {
        return outrasDespesas;
    }

    public void setOutrasDespesas(double outrasDespesas) {
        this.outrasDespesas = outrasDespesas;
    }

    public double getAliquota() {
        return aliquota;
    }

    public void setAliquota(double aliquota) {
        this.aliquota = aliquota;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
