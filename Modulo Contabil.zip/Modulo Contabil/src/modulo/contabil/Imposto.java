package modulo.contabil;

public interface Imposto {

    public double calcularImposto();

    public String getDescricao();

}
